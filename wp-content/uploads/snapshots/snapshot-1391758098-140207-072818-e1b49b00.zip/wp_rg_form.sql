CREATE TABLE IF NOT EXISTS `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_rg_form`;
 
INSERT INTO `wp_rg_form` VALUES ('1', 'Contact Us!', '2014-01-28 09:30:23', '0', '0'); 
INSERT INTO `wp_rg_form` VALUES ('2', 'Contact Us! - Copy 1', '2014-01-28 10:40:32', '1', '0');
# --------------------------------------------------------

