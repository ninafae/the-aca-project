CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_usermeta`;
 
INSERT INTO `wp_usermeta` VALUES ('1', '1', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('2', '1', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('3', '1', 'nickname', 'nina'); 
INSERT INTO `wp_usermeta` VALUES ('4', '1', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('9', '1', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('10', '1', 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('11', '1', 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks'); 
INSERT INTO `wp_usermeta` VALUES ('13', '1', 'show_welcome_panel', '1'); 
INSERT INTO `wp_usermeta` VALUES ('14', '1', 'wp_dashboard_quick_press_last_post_id', '76'); 
INSERT INTO `wp_usermeta` VALUES ('15', '1', 'source_domain', 'acutabovepetsalons.com'); 
INSERT INTO `wp_usermeta` VALUES ('16', '1', 'primary_blog', '1'); 
INSERT INTO `wp_usermeta` VALUES ('17', '1', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `wp_usermeta` VALUES ('18', '1', 'metaboxhidden_nav-menus', 'a:5:{i:0;s:8:"add-post";i:1;s:13:"add-portfolio";i:2;s:12:"add-post_tag";i:3;s:15:"add-post_format";i:4;s:22:"add-portfolio_category";}'); 
INSERT INTO `wp_usermeta` VALUES ('19', '1', 'wp_user-settings', 'libraryContent=browse&editor=html&urlbutton=none&align=center'); 
INSERT INTO `wp_usermeta` VALUES ('20', '1', 'wp_user-settings-time', '1391473664'); 
INSERT INTO `wp_usermeta` VALUES ('21', '1', 'wp_2_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('22', '1', 'wp_2_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('23', '1', 'wp_2_user-settings', 'libraryContent=browse&editor=html&urlbutton=none&align=center'); 
INSERT INTO `wp_usermeta` VALUES ('24', '1', 'wp_2_user-settings-time', '1390887358'); 
INSERT INTO `wp_usermeta` VALUES ('25', '1', 'wp_2_dashboard_quick_press_last_post_id', '34'); 
INSERT INTO `wp_usermeta` VALUES ('26', '1', 'nav_menu_recently_edited', '2'); 
INSERT INTO `wp_usermeta` VALUES ('27', '1', '_wdp_un_has_gravatar', '1'); 
INSERT INTO `wp_usermeta` VALUES ('28', '1', 'wp_3_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('29', '1', 'wp_3_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('30', '1', 'wp_3_user-settings', 'libraryContent=browse&editor=html&urlbutton=none&align=center'); 
INSERT INTO `wp_usermeta` VALUES ('31', '1', 'wp_3_user-settings-time', '1391479871'); 
INSERT INTO `wp_usermeta` VALUES ('32', '1', 'wp_3_dashboard_quick_press_last_post_id', '3'); 
INSERT INTO `wp_usermeta` VALUES ('33', '1', 'wp_4_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('34', '1', 'wp_4_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('35', '1', 'wp_4_user-settings', 'libraryContent=browse&editor=html&urlbutton=none&align=center'); 
INSERT INTO `wp_usermeta` VALUES ('36', '1', 'wp_4_user-settings-time', '1391475834'); 
INSERT INTO `wp_usermeta` VALUES ('37', '1', 'wp_4_dashboard_quick_press_last_post_id', '3');
# --------------------------------------------------------

