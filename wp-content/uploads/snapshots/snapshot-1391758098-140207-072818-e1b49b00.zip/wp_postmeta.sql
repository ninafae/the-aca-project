CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_postmeta`;
 
INSERT INTO `wp_postmeta` VALUES ('1', '2', '_wp_page_template', 'page-fullwidth.php'); 
INSERT INTO `wp_postmeta` VALUES ('2', '4', '_menu_item_type', 'custom'); 
INSERT INTO `wp_postmeta` VALUES ('3', '4', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('4', '4', '_menu_item_object_id', '4'); 
INSERT INTO `wp_postmeta` VALUES ('5', '4', '_menu_item_object', 'custom'); 
INSERT INTO `wp_postmeta` VALUES ('6', '4', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('7', '4', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('8', '4', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('9', '4', '_menu_item_url', 'http://acutabovepetsalons.com/'); 
INSERT INTO `wp_postmeta` VALUES ('10', '4', '_menu_item_orphaned', '1390549551'); 
INSERT INTO `wp_postmeta` VALUES ('11', '5', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('12', '5', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('13', '5', '_menu_item_object_id', '2'); 
INSERT INTO `wp_postmeta` VALUES ('14', '5', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('15', '5', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('16', '5', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('17', '5', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('18', '5', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('19', '5', '_menu_item_orphaned', '1390549551'); 
INSERT INTO `wp_postmeta` VALUES ('20', '6', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('21', '6', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('22', '6', '_menu_item_object_id', '2'); 
INSERT INTO `wp_postmeta` VALUES ('23', '6', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('24', '6', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('25', '6', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('26', '6', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('27', '6', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('29', '7', '_menu_item_type', 'custom'); 
INSERT INTO `wp_postmeta` VALUES ('30', '7', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('31', '7', '_menu_item_object_id', '7'); 
INSERT INTO `wp_postmeta` VALUES ('32', '7', '_menu_item_object', 'custom'); 
INSERT INTO `wp_postmeta` VALUES ('33', '7', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('34', '7', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('35', '7', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('36', '7', '_menu_item_url', 'http://acutabovepetsalons.com/pet-grooming-apprenticeship-program/'); 
INSERT INTO `wp_postmeta` VALUES ('104', '23', '_wp_attached_file', '2014/01/logo-footer.png'); 
INSERT INTO `wp_postmeta` VALUES ('105', '23', '_wp_attachment_metadata', 'a:4:{s:5:"width";i:104;s:6:"height";i:31;s:4:"file";s:23:"2014/01/logo-footer.png";s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_postmeta` VALUES ('106', '23', '_edit_lock', '1390555258:1'); 
INSERT INTO `wp_postmeta` VALUES ('107', '23', '_wp_attachment_image_alt', 'A Cut Above Pet Salons'); 
INSERT INTO `wp_postmeta` VALUES ('108', '23', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('110', '25', '_wp_attached_file', '2014/01/slide1.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('111', '25', '_wp_attachment_metadata', 'a:4:{s:5:"width";i:940;s:6:"height";i:439;s:4:"file";s:18:"2014/01/slide1.jpg";s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_postmeta` VALUES ('112', '26', '_wp_attached_file', '2014/01/slide4.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('113', '26', '_wp_attachment_metadata', 'a:4:{s:5:"width";i:940;s:6:"height";i:439;s:4:"file";s:18:"2014/01/slide4.jpg";s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_postmeta` VALUES ('114', '27', '_edit_lock', '1390558732:1'); 
INSERT INTO `wp_postmeta` VALUES ('115', '25', '_wp_attachment_image_alt', 'Dog Grooming'); 
INSERT INTO `wp_postmeta` VALUES ('116', '27', '_thumbnail_id', '25'); 
INSERT INTO `wp_postmeta` VALUES ('117', '27', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('118', '28', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('119', '28', '_edit_lock', '1390652357:1'); 
INSERT INTO `wp_postmeta` VALUES ('120', '26', '_wp_attachment_image_alt', 'Cat Grooming'); 
INSERT INTO `wp_postmeta` VALUES ('121', '28', '_thumbnail_id', '26'); 
INSERT INTO `wp_postmeta` VALUES ('123', '28', 'Cats', 'The best grooming experience your kitty will ever have.'); 
INSERT INTO `wp_postmeta` VALUES ('124', '27', 'Dogs', 'The best grooming experience your pup will ever have.'); 
INSERT INTO `wp_postmeta` VALUES ('127', '2', '_edit_lock', '1390884381:1'); 
INSERT INTO `wp_postmeta` VALUES ('128', '2', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('129', '32', '_wp_attached_file', '2014/01/logo.png'); 
INSERT INTO `wp_postmeta` VALUES ('130', '32', '_wp_attachment_metadata', 'a:4:{s:5:"width";i:199;s:6:"height";i:136;s:4:"file";s:16:"2014/01/logo.png";s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_postmeta` VALUES ('131', '32', '_edit_lock', '1390595955:1'); 
INSERT INTO `wp_postmeta` VALUES ('132', '32', '_wp_attachment_image_alt', 'A Cut Above Pet Salons'); 
INSERT INTO `wp_postmeta` VALUES ('133', '32', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('134', '34', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('135', '34', '_edit_lock', '1390596508:1'); 
INSERT INTO `wp_postmeta` VALUES ('136', '35', '_wp_attached_file', '2014/01/coming-soon.png'); 
INSERT INTO `wp_postmeta` VALUES ('137', '35', '_wp_attachment_metadata', 'a:4:{s:5:"width";i:940;s:6:"height";i:439;s:4:"file";s:23:"2014/01/coming-soon.png";s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_postmeta` VALUES ('138', '35', '_edit_lock', '1390596548:1'); 
INSERT INTO `wp_postmeta` VALUES ('139', '35', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('140', '34', '_wp_page_template', 'page-fullwidth.php'); 
INSERT INTO `wp_postmeta` VALUES ('141', '37', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('142', '37', '_edit_lock', '1390900692:1'); 
INSERT INTO `wp_postmeta` VALUES ('143', '37', '_wp_page_template', 'page-fullwidth.php'); 
INSERT INTO `wp_postmeta` VALUES ('144', '39', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('145', '39', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('146', '39', '_menu_item_object_id', '37'); 
INSERT INTO `wp_postmeta` VALUES ('147', '39', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('148', '39', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('149', '39', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('150', '39', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('151', '39', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('168', '49', '_wp_attached_file', '2014/01/logo-icon.png'); 
INSERT INTO `wp_postmeta` VALUES ('169', '49', '_wp_attachment_metadata', 'a:4:{s:5:"width";i:32;s:6:"height";i:32;s:4:"file";s:21:"2014/01/logo-icon.png";s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'); 
INSERT INTO `wp_postmeta` VALUES ('170', '49', '_wp_attachment_image_alt', 'A Cut Above'); 
INSERT INTO `wp_postmeta` VALUES ('196', '65', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('197', '65', '_edit_lock', '1391475592:1'); 
INSERT INTO `wp_postmeta` VALUES ('198', '65', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('199', '78', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('200', '78', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('201', '78', '_menu_item_object_id', '65'); 
INSERT INTO `wp_postmeta` VALUES ('202', '78', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('203', '78', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('204', '78', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('205', '78', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('206', '78', '_menu_item_url', '');
# --------------------------------------------------------

