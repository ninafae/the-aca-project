CREATE TABLE IF NOT EXISTS `wp_blogs` (
  `blog_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `domain` varchar(200) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `public` tinyint(2) NOT NULL DEFAULT '1',
  `archived` tinyint(2) NOT NULL DEFAULT '0',
  `mature` tinyint(2) NOT NULL DEFAULT '0',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  `lang_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`blog_id`),
  KEY `domain` (`domain`(50),`path`(5)),
  KEY `lang_id` (`lang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_blogs`;
 
INSERT INTO `wp_blogs` VALUES ('1', '1', 'acutabovepetsalons.com', '/', '2014-01-24 07:18:38', '2014-02-04 01:01:41', '1', '0', '0', '0', '0', '0'); 
INSERT INTO `wp_blogs` VALUES ('2', '1', 'acutabovepetsalons.com', '/pet-grooming-apprenticeship-program/', '2014-01-24 17:39:18', '2014-01-25 10:16:21', '1', '0', '0', '0', '0', '0'); 
INSERT INTO `wp_blogs` VALUES ('3', '1', 'acutabovepetsalons.com', '/east-millcreek/', '2014-01-28 02:49:05', '2014-02-04 06:42:51', '1', '0', '0', '0', '0', '0'); 
INSERT INTO `wp_blogs` VALUES ('4', '1', 'acutabovepetsalons.com', '/murray/', '2014-02-03 23:54:08', '2014-02-04 06:43:09', '1', '0', '0', '0', '0', '0');
# --------------------------------------------------------

