CREATE TABLE IF NOT EXISTS `wp_sitemeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `meta_key` (`meta_key`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=912 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_sitemeta`;
 
INSERT INTO `wp_sitemeta` VALUES ('1', '1', 'site_name', 'A Cut Above Pet Salons'); 
INSERT INTO `wp_sitemeta` VALUES ('2', '1', 'admin_email', 'nina@mypowerline.org'); 
INSERT INTO `wp_sitemeta` VALUES ('3', '1', 'admin_user_id', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('4', '1', 'registration', 'none'); 
INSERT INTO `wp_sitemeta` VALUES ('5', '1', 'upload_filetypes', 'jpg jpeg png gif mp3 mov avi wmv midi mid pdf'); 
INSERT INTO `wp_sitemeta` VALUES ('6', '1', 'blog_upload_space', '100'); 
INSERT INTO `wp_sitemeta` VALUES ('7', '1', 'fileupload_maxk', '1500'); 
INSERT INTO `wp_sitemeta` VALUES ('8', '1', 'site_admins', 'a:1:{i:0;s:4:"nina";}'); 
INSERT INTO `wp_sitemeta` VALUES ('9', '1', 'allowedthemes', 'a:2:{s:14:"twentyfourteen";b:1;s:9:"theme1619";b:1;}'); 
INSERT INTO `wp_sitemeta` VALUES ('10', '1', 'illegal_names', 'a:9:{i:0;s:3:"www";i:1;s:3:"web";i:2;s:4:"root";i:3;s:5:"admin";i:4;s:4:"main";i:5;s:6:"invite";i:6;s:13:"administrator";i:7;s:5:"files";i:8;s:4:"blog";}'); 
INSERT INTO `wp_sitemeta` VALUES ('11', '1', 'wpmu_upgrade_site', '26691'); 
INSERT INTO `wp_sitemeta` VALUES ('12', '1', 'welcome_email', 'Dear User,\n\nYour new SITE_NAME site has been successfully set up at:\nBLOG_URL\n\nYou can log in to the administrator account with the following information:\nUsername: USERNAME\nPassword: PASSWORD\nLog in here: BLOG_URLwp-login.php\n\nWe hope you enjoy your new site. Thanks!\n\n--The Team @ SITE_NAME'); 
INSERT INTO `wp_sitemeta` VALUES ('13', '1', 'first_post', 'Welcome to <a href="SITE_URL">SITE_NAME</a>. This is your first post. Edit or delete it, then start blogging!'); 
INSERT INTO `wp_sitemeta` VALUES ('14', '1', 'siteurl', 'http://acutabovepetsalons.com/'); 
INSERT INTO `wp_sitemeta` VALUES ('15', '1', 'add_new_users', '0'); 
INSERT INTO `wp_sitemeta` VALUES ('16', '1', 'upload_space_check_disabled', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('17', '1', 'subdomain_install', '0'); 
INSERT INTO `wp_sitemeta` VALUES ('18', '1', 'global_terms_enabled', '0'); 
INSERT INTO `wp_sitemeta` VALUES ('19', '1', 'ms_files_rewriting', '0'); 
INSERT INTO `wp_sitemeta` VALUES ('20', '1', 'initial_db_version', '26691'); 
INSERT INTO `wp_sitemeta` VALUES ('21', '1', 'active_sitewide_plugins', 'a:5:{s:29:"gravityforms/gravityforms.php";i:1390597148;s:33:"w3-total-cache/w3-total-cache.php";i:1390859798;s:40:"wpmudev-updates/update-notifications.php";i:1390868614;s:35:"gravityformsmailchimp/mailchimp.php";i:1391471670;s:21:"snapshot/snapshot.php";i:1391757838;}'); 
INSERT INTO `wp_sitemeta` VALUES ('22', '1', 'WPLANG', 'en_US'); 
INSERT INTO `wp_sitemeta` VALUES ('23', '1', '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:41:"https://wordpress.org/wordpress-3.8.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:41:"https://wordpress.org/wordpress-3.8.1.zip";s:10:"no_content";s:52:"https://wordpress.org/wordpress-3.8.1-no-content.zip";s:11:"new_bundled";s:53:"https://wordpress.org/wordpress-3.8.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.8.1";s:7:"version";s:5:"3.8.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1390859795;s:15:"version_checked";s:5:"3.8.1";s:12:"translations";a:0:{}}'); 
INSERT INTO `wp_sitemeta` VALUES ('27', '1', '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1390859796;s:7:"checked";a:4:{s:9:"theme1619";s:0:"";s:14:"twentyfourteen";s:3:"1.0";s:14:"twentythirteen";s:3:"1.1";s:12:"twentytwelve";s:3:"1.3";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}'); 
INSERT INTO `wp_sitemeta` VALUES ('28', '1', 'user_count', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('29', '1', 'blog_count', '4'); 
INSERT INTO `wp_sitemeta` VALUES ('30', '1', 'can_compress_scripts', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('31', '1', '_site_transient_timeout_wporg_theme_feature_list', '1390559707'); 
INSERT INTO `wp_sitemeta` VALUES ('32', '1', '_site_transient_wporg_theme_feature_list', 'a:0:{}'); 
INSERT INTO `wp_sitemeta` VALUES ('33', '1', '_site_transient_timeout_browser_3665d7cabf3a9b8285d951fd972d877f', '1391154117'); 
INSERT INTO `wp_sitemeta` VALUES ('34', '1', '_site_transient_browser_3665d7cabf3a9b8285d951fd972d877f', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"32.0.1700.77";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}'); 
INSERT INTO `wp_sitemeta` VALUES ('46', '1', '_site_transient_timeout_GFCache_36c6e30a338ed8e9afd1b98908a3973d', '1390597322'); 
INSERT INTO `wp_sitemeta` VALUES ('47', '1', '_site_transient_GFCache_36c6e30a338ed8e9afd1b98908a3973d', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('48', '1', '_site_transient_timeout_GFCache_bd26bc8eefe8ac28f82a36bba23601f2', '1390597337'); 
INSERT INTO `wp_sitemeta` VALUES ('49', '1', '_site_transient_GFCache_bd26bc8eefe8ac28f82a36bba23601f2', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('50', '1', '_site_transient_timeout_GFCache_b601e5631f6c98559cca7b7c6dc11213', '1390597340'); 
INSERT INTO `wp_sitemeta` VALUES ('51', '1', '_site_transient_GFCache_b601e5631f6c98559cca7b7c6dc11213', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('74', '1', '_site_transient_timeout_GFCache_77c542cffa741266e59602d4f9bdf647', '1390604702'); 
INSERT INTO `wp_sitemeta` VALUES ('75', '1', '_site_transient_GFCache_77c542cffa741266e59602d4f9bdf647', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('76', '1', '_site_transient_timeout_GFCache_09696c920a2e3874f24d5d943d11b329', '1390606474'); 
INSERT INTO `wp_sitemeta` VALUES ('77', '1', '_site_transient_GFCache_09696c920a2e3874f24d5d943d11b329', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('122', '1', '_site_transient_timeout_GFCache_830162e48c8d0e4d30935bfc122f2366', '1390631463'); 
INSERT INTO `wp_sitemeta` VALUES ('123', '1', '_site_transient_GFCache_830162e48c8d0e4d30935bfc122f2366', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('124', '1', '_site_transient_timeout_GFCache_d85028323dba73595276262e02e41630', '1390631346'); 
INSERT INTO `wp_sitemeta` VALUES ('125', '1', '_site_transient_GFCache_d85028323dba73595276262e02e41630', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('132', '1', '_site_transient_timeout_GFCache_2421834afc07ab3f3227f4ed380bbc41', '1390650178'); 
INSERT INTO `wp_sitemeta` VALUES ('133', '1', '_site_transient_GFCache_2421834afc07ab3f3227f4ed380bbc41', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('134', '1', '_site_transient_timeout_GFCache_ef1597734db80dbc862d151451d796e9', '1390650183'); 
INSERT INTO `wp_sitemeta` VALUES ('135', '1', '_site_transient_GFCache_ef1597734db80dbc862d151451d796e9', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('869', '1', '_site_transient_timeout_GFCache_ccb70ffddd88e4747407f43226f5f48a', '1390694406'); 
INSERT INTO `wp_sitemeta` VALUES ('870', '1', '_site_transient_GFCache_ccb70ffddd88e4747407f43226f5f48a', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('883', '1', '_site_transient_timeout_gforms_mailchimp_version', '1390898463'); 
INSERT INTO `wp_sitemeta` VALUES ('884', '1', '_site_transient_gforms_mailchimp_version', '-1'); 
INSERT INTO `wp_sitemeta` VALUES ('885', '1', '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1390870544'); 
INSERT INTO `wp_sitemeta` VALUES ('886', '1', '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}'); 
INSERT INTO `wp_sitemeta` VALUES ('887', '1', '_site_transient_timeout_theme_roots', '1390861593'); 
INSERT INTO `wp_sitemeta` VALUES ('888', '1', '_site_transient_theme_roots', 'a:4:{s:9:"theme1619";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}'); 
INSERT INTO `wp_sitemeta` VALUES ('889', '1', '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1390859798;s:7:"checked";a:5:{s:19:"akismet/akismet.php";s:5:"2.5.9";s:29:"gravityforms/gravityforms.php";s:5:"1.8.3";s:35:"gravityformsmailchimp/mailchimp.php";s:3:"2.3";s:9:"hello.php";s:3:"1.6";s:33:"w3-total-cache/w3-total-cache.php";s:5:"0.9.3";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}'); 
INSERT INTO `wp_sitemeta` VALUES ('890', '1', 'wdp_un_limit_to_user', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('891', '1', 'wdp_un_refresh_updates_flag', '0'); 
INSERT INTO `wp_sitemeta` VALUES ('892', '1', 'wdp_un_local_themes', 'a:0:{}'); 
INSERT INTO `wp_sitemeta` VALUES ('893', '1', 'wdp_un_last_run', '1391757841'); 
INSERT INTO `wp_sitemeta` VALUES ('894', '1', 'wdp_un_hide_upgrades', '0'); 
INSERT INTO `wp_sitemeta` VALUES ('895', '1', 'wdp_un_hide_notices', '0'); 
INSERT INTO `wp_sitemeta` VALUES ('896', '1', 'wdp_un_hide_releases', '0'); 
INSERT INTO `wp_sitemeta` VALUES ('897', '1', 'wdp_un_updates_available', 'a:0:{}'); 
INSERT INTO `wp_sitemeta` VALUES ('898', '1', 'wdp_un_redirected', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('899', '1', 'wpmudev_apikey', '1712e42799ebce0d3f2b45f4f96347f9fcdb3bf3'); 
INSERT INTO `wp_sitemeta` VALUES ('900', '1', 'wdp_un_delay', '1390955637'); 
INSERT INTO `wp_sitemeta` VALUES ('901', '1', 'blogs_directory_page_setup', 'completelocations'); 
INSERT INTO `wp_sitemeta` VALUES ('902', '1', 'blogs_directory_sort_by', 'latest'); 
INSERT INTO `wp_sitemeta` VALUES ('903', '1', 'blogs_directory_per_page', '10'); 
INSERT INTO `wp_sitemeta` VALUES ('904', '1', 'blogs_directory_background_color', '#f0f0f0'); 
INSERT INTO `wp_sitemeta` VALUES ('905', '1', 'blogs_directory_alternate_background_color', '#f6f5f5'); 
INSERT INTO `wp_sitemeta` VALUES ('906', '1', 'blogs_directory_border_color', '#CFD0CB'); 
INSERT INTO `wp_sitemeta` VALUES ('907', '1', 'blogs_directory_hide_blogs', ''); 
INSERT INTO `wp_sitemeta` VALUES ('908', '1', 'blogs_directory_show_description', '1'); 
INSERT INTO `wp_sitemeta` VALUES ('909', '1', 'blogs_directory_title_blogs_page', 'Locations'); 
INSERT INTO `wp_sitemeta` VALUES ('910', '1', 'registrationnotification', 'yes'); 
INSERT INTO `wp_sitemeta` VALUES ('911', '1', 'welcome_user_email', 'Dear User,\n\nYour new account is set up.\n\nYou can log in with the following information:\nUsername: USERNAME\nPassword: PASSWORD\nLOGINLINK\n\nThanks!\n\n--The Team @ SITE_NAME');
# --------------------------------------------------------

