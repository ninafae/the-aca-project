CREATE TABLE IF NOT EXISTS `wp_registration_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL DEFAULT '',
  `IP` varchar(30) NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `IP` (`IP`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_registration_log`;
 
INSERT INTO `wp_registration_log` VALUES ('1', 'nina@mypowerline.org', '50.160.120.157', '2', '2014-01-24 17:39:19'); 
INSERT INTO `wp_registration_log` VALUES ('2', 'nina@mypowerline.org', '50.160.120.157', '3', '2014-01-28 02:49:06'); 
INSERT INTO `wp_registration_log` VALUES ('3', 'nina@mypowerline.org', '50.160.120.157', '4', '2014-02-03 23:54:09');
# --------------------------------------------------------

